# Nada

Well clearly this isn't nothing...

## Running

```
docker compose up
```

Then make api requests to `http://localhost:5000` with an `curl` or your favorite HTTP client.
