# Font Review

I'm a graphic designer trying to improve my typography skills. Let me review your font!

## Running

```
docker compose up
```

Then access [http://localhost:3001](http://localhost:3001) in your browser.
