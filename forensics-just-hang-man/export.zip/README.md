# Just hang, man

A completely regular conversation of two people playing hangman.

Hint: Some guesses are worse than others
