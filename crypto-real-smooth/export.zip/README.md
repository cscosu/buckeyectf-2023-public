# Real Smooth

I know you're not supposed to leave passwords in plain text so I encrypted them.
