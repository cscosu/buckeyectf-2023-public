# Emotional Damage

Emojis be bussin fr fr

## Running

Install GHC.

The flag is the output. Find what functions are supposed to be there and replace the emojis with the correct function names.
