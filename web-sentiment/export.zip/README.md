# Sentiment

All your notes, in one place.

## Running

```
docker compose up
```

Then access [http://localhost:3001](http://localhost:3001) in your browser.
